Skyward v1.0.0（小米15 Ultra xuanyuan）
镜像：skyward-v1.0.0-xuanyuan-OS4.0.0.18.XOACNXM.img
SHA256：f797dcfae02e801a4962b4331da3c7e29c2e19e1465191858de995c17cc0589c
底包：HyperOS OS4.0.0.18.XOACNXM 原厂 recovery。AVB footer 算法 NONE。
适用：小米15 Ultra（xuanyuan），已解锁 Bootloader。ColorOS 17 移植与原厂 HyperOS 均可用。

支持的功能
解密与安全
- 用锁屏密码解密 data，支持密钥只绑定 weaver（Thales 安全元件）的用户
- keymint、gatekeeper、weaver、se_omapi 完整链路，重启后残留 socket 自动清理
刷机
- 安装卡刷包、系统更新包，支持内部存储、U 盘和 adb sideload
- 卡刷包脚本可用 7za、zstd、unzip -p、avbctl、resetprop
- 刷入单个分区镜像（boot、vendor_boot、dtbo、recovery 等）
- 刷入 super.img（raw 与 sparse），读写并行，大镜像 8 MiB 块
- 刷入单个逻辑分区（system、vendor、odm、product 等，erofs/ext4/f2fs，raw 或 sparse），
  选分区和槽位即可；不能扩容，镜像大于分区会被拒绝
- 禁用 AVB2.0：同 TWRP R7，只关闭两个槽位顶层 vbmeta 的 dm-verity（flags 置 0x1），
  vbmeta_system、vbmeta_vendor 保持 0。可在「高级」里执行，或在安装选项里设为刷入后自动执行
- 在线系统更新（小米官方），Virtual A/B 快照映射与合并
- 从 GitHub zhouzt0121/skyward 的最新 Release 在线更新本 recovery
数据与工具
- 备份和恢复、清除数据、恢复出厂设置
- 挂载、修复、格式化分区
- 文件管理、终端
- WLAN（qca_cld3_peach_v2）、MTP、adb、fastbootd
- 重启到系统、recovery、fastboot、bootloader、EDL，切换槽位
- 双系统卡片切换
体验
- 熄屏后双击亮屏（通过 /dev/xiaomi-touch 打开触控双击模式）
- 震动反馈；失败时只关马达，不会重启
- 浅色/深色主题，简体中文、繁体中文、英文

未实现
- snapuserd 压缩快照的更新、增量更新包、非 A/B 机型的更新包
- 逻辑分区扩容（需改 super 元数据）
- sparse 格式的 super 暂未并行写入

注意
- super 与超过 512 MiB 的镜像写完只 sync，不整盘回读校验；小镜像仍写后回读。刷完请立即重启。
- 曾用测试版（v6）禁用过 AVB、开机卡 fastboot 的：进本 recovery 再执行一次禁用 AVB2.0 即可恢复，
  或在 fastboot 刷回原版 vbmeta：
    fastboot --disable-verity flash vbmeta_a vbmeta.img（_b 同）
    fastboot flash vbmeta_system_a vbmeta_system.img（_b 同）

刷入前先备份原厂 recovery：
  dd if=/dev/block/by-name/recovery_a of=/sdcard/recovery_a_stock.img
  dd if=/dev/block/by-name/recovery_b of=/sdcard/recovery_b_stock.img
刷入（无需格式化 data）：
  fastboot flash recovery_a skyward-v1.0.0-xuanyuan-OS4.0.0.18.XOACNXM.img
  fastboot flash recovery_b skyward-v1.0.0-xuanyuan-OS4.0.0.18.XOACNXM.img

致谢：基于 Kirk Lin 的 Skyward（github.com/kirklin/skyward），以及澪洛依（Rinrroy）的
skyward-for-haotian 分支，包括 socket 支持、震动初始化和解密链。se_omapi 的 AIDL 库取自 TWRP R7。
禁用 AVB 做法参照 YuKongA 的 TWRP（commit 051d8a35）。
许可证：GPLv3。源码：github.com/zhouzt0121/skyward
